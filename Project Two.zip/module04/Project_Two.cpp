#include <iostream>             // cout, cerr
#include <cstdlib>              // EXIT_FAILURE
#include <GL/glew.h>            // GLEW library
#include <GLFW/glfw3.h>         // GLFW library
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>      // Image loading Utility functions

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <learnOpengl/camera.h> // Camera class

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
const char* const WINDOW_TITLE = "Jason Veno Project Two"; // Macro for window title

// Variables for window width and height
const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 600;
float heightScale = 0.1;

// Stores the GL data relative to a given mesh
struct GLMesh
{
    GLuint planeVao, cuboidVao, lensVao, dunderVao, mapVao, rubikVao, lightVao;         // Handle for the vertex array object
    GLuint planeVbo, cuboidVbo, lensVbo, dunderVbo, mapVbo, rubikVbo, lightVbo;         // Handle for the vertex buffer object
    GLuint planeVertices, cuboidVertices, lensVertices, dunderVertices, mapVertices, rubikVertices, lightVertices;    // Number of indices of the mesh
};


// Main GLFW window
GLFWwindow* gWindow = nullptr;
// Triangle mesh data
GLMesh gMesh;
// Texture id
GLuint gTextureIdPlane, gTextureIdCuboid, gTextureIdLens, gTextureIdDunder, gTextureIdMap, gTextureIdRubik, gTextureIdLight;
glm::vec2 gUVScale(1.0f, 1.0f); //  ADDED FOR MOD 6 MILESTONE Was 5.0f, 5.0f
// Shader program
GLuint gProgramId;
GLuint gLightProgramId; // ADDED FOR MOD 6 MILESTONE

// camera

float x_camera = 0.0f, y_camera = 0.0f, z_camera = 10.0f;
Camera gCamera(glm::vec3(x_camera, y_camera, z_camera));
glm::vec3 gCameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
 
float gLastX = WINDOW_WIDTH / 2.0f;
float gLastY = WINDOW_HEIGHT / 2.0f;
bool gFirstMouse = true;

// timing
float gDeltaTime = 0.0f; // time between current frame and last frame
float gLastFrame = 0.0f;


// ADDED  FOR MOD 6 MILESTONE
// Light position and scale
glm::vec3 gLightPosition(0.0f, 0.0f, 0.0f);
glm::vec3 gLightScale(0.3f);
//glm::vec3 gLightColor(1.0f, 1.0f, 1.0f);
glm::vec4 gLightColor(1.0f, 1.0f, 1.0f, 1.0f);


}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char*[], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMeshPlane(GLMesh &mesh);
void UCreateMeshCuboid(GLMesh& mesh);
void UCreateMeshLens(GLMesh& mesh);
void UCreateMeshDunder(GLMesh& mesh);
void UCreateMeshMap(GLMesh& mesh);
void UCreateMeshRubik(GLMesh& mesh);
void UCreateMeshLight(GLMesh& mesh);
void UDestroyMesh(GLMesh &mesh);
bool UCreateTexture(const char* filename, GLuint &textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint &programId);
void UDestroyShaderProgram(GLuint programId);


/* Vertex Shader Source Code*/
const GLchar * vertexShaderSource = GLSL(440,
    layout (location = 0) in vec3 position; // Vertex data from Vertex Attrib Pointer 0
    layout (location = 1) in vec2 textureCoordinate;  // Color data from Vertex Attrib Pointer 1

    out vec2 vertexTextureCoordinate;


    //Global variables for the transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates
        vertexTextureCoordinate = textureCoordinate;
    }
);


/* Fragment Shader Source Code*/
const GLchar * fragmentShaderSource = GLSL(440,
    in vec2 vertexTextureCoordinate; // Variable to hold incoming texture data from vertex shader

    out vec4 fragmentColor;

    uniform sampler2D uTexture;
    uniform vec3 lightColor; // ADDED FOR MOD 6 MILESTONE
    uniform vec2 uvScale;    // ADDED FOR MOD 6 MILESTONE

    void main()
    {
        // ADDED FOR MOD 6 MILESTONE
        vec4 ambient = vec4(1.5f, 1.5f, 1.5f, 1.5f);
        vec4 textureColor = texture(uTexture, vertexTextureCoordinate);
        // END ADDED FOR MOD 6 MILESTONE

        fragmentColor = textureColor * ambient;
    }
);





// ADDED FOR MOD 6 MILESTONE
/* Light Shader Source Code*/
const GLchar* lightVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

        //Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);

// ADDED FOR MOD 6 MILESTONE
/* Fragment Shader Source Code*/
const GLchar* lightFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU


void main()
{
    fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0 
}
);






// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char *image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the plane mesh
    UCreateMeshPlane(gMesh); // Calls the function to create the Vertex Buffer Object

    // Create the shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    // ADDED FOR MOD 6 MILESTONE
    if (!UCreateShaderProgram(lightVertexShaderSource, lightFragmentShaderSource, gLightProgramId))
        return EXIT_FAILURE;



    // Load wood texture
    const char * texFilename = "wood.jpg";
    if (!UCreateTexture(texFilename, gTextureIdPlane))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    // Release texture
    UDestroyTexture(gTextureIdPlane);

    // Create cuboid mesh
    UCreateMeshCuboid(gMesh);

    // Load plastic texture
    const char* texFilename2 = "plastic.jpg";
    if (!UCreateTexture(texFilename2, gTextureIdCuboid))
    {
        cout << "Failed to load texture " << texFilename2 << endl;
        return EXIT_FAILURE;
    }

    // Release texture
    UDestroyTexture(gTextureIdCuboid);

    // Create lens mesh
    UCreateMeshLens(gMesh);

    // Load glass texture
    const char* texFilename3 = "glass.jpg";
    if (!UCreateTexture(texFilename3, gTextureIdLens))
    {
        cout << "Failed to load texture " << texFilename3 << endl;
        return EXIT_FAILURE;
    }

    // Release texture
    UDestroyTexture(gTextureIdLens);


    // Create dunder mesh
    UCreateMeshDunder(gMesh);

    // Load plastic texture
    const char* texFilename5 = "dunder.jpg";
    if (!UCreateTexture(texFilename5, gTextureIdDunder))
    {
        cout << "Failed to load texture " << texFilename5 << endl;
        return EXIT_FAILURE;
    }

    // Release texture
    UDestroyTexture(gTextureIdDunder);

    // Create map mesh
    UCreateMeshMap(gMesh);

    // Load plastic texture
    const char* texFilename6 = "map.jpg";
    if (!UCreateTexture(texFilename6, gTextureIdMap))
    {
        cout << "Failed to load texture " << texFilename6 << endl;
        return EXIT_FAILURE;
    }

    // Release texture
    UDestroyTexture(gTextureIdMap);

    // Create cuboid mesh
    UCreateMeshRubik(gMesh);

    // Load plastic texture
    const char* texFilename7 = "rubik.jpg";
    if (!UCreateTexture(texFilename7, gTextureIdRubik))
    {
        cout << "Failed to load texture " << texFilename7 << endl;
        return EXIT_FAILURE;
    }

    // Release texture
    UDestroyTexture(gTextureIdRubik);


    // ADDED FOR MOD 6 MILESTONE
    // Create lens mesh
    UCreateMeshLight(gMesh);

    // Load glass texture
    const char* texFilename4 = "light.jpg";
    if (!UCreateTexture(texFilename4, gTextureIdLight))
    {
        cout << "Failed to load texture " << texFilename4 << endl;
        return EXIT_FAILURE;
    }
    // END ADDED FOR MOD 6 MILESTONE



    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gMesh);

    // Release texture
    UDestroyTexture(gTextureIdLight);

    // Release shader program
    UDestroyShaderProgram(gProgramId);
    UDestroyShaderProgram(gLightProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    *window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    float cameraOffset = cameraSpeed * gDeltaTime; 

    
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);



    
    // Uses Q and E to make camera move up and down 
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        glm::mat4 translation = glm::translate(glm::vec3(0.0f, 1.0f, 0.0f));
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        glm::mat4 translation = glm::translate(glm::vec3(0.0f, -1.0f, 0.0f));
    
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
        case GLFW_MOUSE_BUTTON_LEFT:
        {
            if (action == GLFW_PRESS)
                cout << "Left mouse button pressed" << endl;
            else
                cout << "Left mouse button released" << endl;
        }
        break;

        case GLFW_MOUSE_BUTTON_MIDDLE:
        {
            if (action == GLFW_PRESS)
                cout << "Middle mouse button pressed" << endl;
            else
                cout << "Middle mouse button released" << endl;
        }
        break;

        case GLFW_MOUSE_BUTTON_RIGHT:
        {
            if (action == GLFW_PRESS)
                cout << "Right mouse button pressed" << endl;
            else
                cout << "Right mouse button released" << endl;
        }
        break;

        default:
            cout << "Unhandled mouse button event" << endl;
            break;
    }
}


// Function called to render a frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);
    
    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::mat4 model = glm::mat4(1.0);


    // camera/view transformation
    glm::mat4 view = gCamera.GetViewMatrix();
    

    // Creates a perspective projection
    glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

     
    // Activate the PLANE VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.planeVao);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdPlane);

    // Draws the PLANE triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.planeVertices);
    // Deactivate the PLANE Vertex Array Object
    glBindVertexArray(0);


    // Activate the CUBOID VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.cuboidVao);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdCuboid);

    // Draws the CUBOID triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.cuboidVertices);
    // Deactivate the CUBOID Vertex Array Object
    glBindVertexArray(0); 


    // Activate the LENS VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.lensVao);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdLens);

    // Draws the LENS triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.lensVertices);
    // Deactivate the LENS Vertex Array Object
    glBindVertexArray(0);

    // Activate the DUNDER VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.dunderVao);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdDunder);

    // Draws the DUNDER triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.dunderVertices);
    // Deactivate the LENS Vertex Array Object
    glBindVertexArray(0);


    // Activate the MAP VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.mapVao);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdMap);

    // Draws the MAP triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.mapVertices);
    // Deactivate the LENS Vertex Array Object
    glBindVertexArray(0);



    // Activate the RUBIK VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.rubikVao);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdRubik);

    // Draws the RUBIK triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.rubikVertices);
    // Deactivate the LENS Vertex Array Object
    glBindVertexArray(0);


    /*
    // Activate the Light VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.lightVao);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdLight);

    // Draws the LIGHT triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.lightVertices);
    // Deactivate the LIGHT Vertex Array Object
    glBindVertexArray(0);
    */


    // ADDED FOR MOD 6 MILESTONE
    // Light: draw light 
    //----------------
    glUseProgram(gLightProgramId);

    //Transform the smaller cube used as a visual que for the light source
    model = glm::translate(gLightPosition) * glm::scale(gLightScale);
    //glm::mat4 model = glm::mat4(1.0);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLightProgramId, "model");
    viewLoc = glGetUniformLocation(gLightProgramId, "view");
    projLoc = glGetUniformLocation(gLightProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glDrawArrays(GL_TRIANGLES, 0, gMesh.lightVertices);

    // END ADDED FOR MOD 6 MILESTONE


    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}


// Implements the UCreateMeshPlane function
void UCreateMeshPlane(GLMesh& mesh)
{
    // Vertex data
    GLfloat planeVerts[] = {

        -3.0f, -3.0f, -0.5f, 1.0f, 0.0f, // 0
        10.0f, -3.0f, -0.5f, 0.0f, 0.0f, // 1
        -3.0f, 10.0f, -0.5f, 1.0f, 1.0f, // 3
         // End tri 1

        // ------------------
        10.0f, -3.0f, -0.5f, 0.0f, 0.0f,// 1
        10.0f, 10.0f, -0.5f, 0.0f, 1.0f,// 2
        -3.0f, 10.0f, -0.5f, 1.0f, 1.0f, // 3
         // End tri 2
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerUV = 2;

    mesh.planeVertices = sizeof(planeVerts) / (sizeof(planeVerts[0]) * (floatsPerVertex + floatsPerUV));

    glGenVertexArrays(1, &mesh.planeVao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.planeVao);

    // Create VBO
    glGenBuffers(1, &mesh.planeVbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.planeVbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(planeVerts), planeVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

}

// Implements the UCreateMeshcuboid function
void UCreateMeshCuboid(GLMesh& mesh)
{
    GLfloat cuboidVerts[] = {

        0.0f, -0.5f, -0.5f, // 0
        1.0f, 0.0f,  // red 

        3.0f, -0.5f, -0.5f, // 1
        0.0f, 0.0f, // 

        3.0f, 0.5f, -0.5f, // 2
        0.0f, 1.0f, // end tri 1

        // ------------------

        0.0f, -0.5f, -0.5f, // 0
            1.0f, 0.0f,  // 

        3.0f, 0.5f, -0.5f, // 2
            0.0f, 1.0f, //  

        0.0f, 0.5f, -0.5f, // 3
            1.0f, 1.0f, // end tri 2

        // ------------------

        0.0f, -0.5f, -0.5f, // 0
            0.0f, 0.0f, // red

        3.0f, -0.5f, -0.5f, // 1
            1.0f, 0.0f, // 

        3.0f, -0.5f, 0.0f, // 5
            1.0f, 1.0f,// end tri 3

        // ------------------

        0.0f, -0.5f, -0.5f, // 0
            0.0f, 0.0f,  // red

        0.0f, -0.5f, 0.0f, // 4
            0.0f, 1.0f, // red

        3.0f, -0.5f, 0.0f, // 5
            1.0f, 1.0f,// end tri 4

        // ------------------

        3.0f, 0.5f, -0.5f, // 2
            1.0f, 1.0f,  // 

        0.0f, 0.5f, -0.5f, // 3
            1.0f, 0.0f, // 

        3.0f, 0.5f, 0.0f, // 6
            0.0f, 0.0f, // end tri 5

        // ------------------

        3.0f, 0.5f, 0.0f, // 6
            0.0f, 0.0f,  // 

        0.0f, 0.5f, -0.5f, // 3
            0.0f, 1.0f, //

        0.0f, 0.5f, 0.0f, // 7
            1.0f, 1.0f, // end tri 6

        // ------------------

        0.0f, -0.5f, 0.0f, // 4
            1.0f, 1.0f,  // red

        3.0f, -0.5f, 0.0f, // 5
            1.0f, 0.0f, // 

        3.0f, 0.5f, 0.0f, // 6
            0.0f, 0.0f, // end tri 7

        // ------------------

        0.0f, -0.5f, 0.0f, // 4
            1.0f, 1.0f,  // red

        3.0f, 0.5f, 0.0f, // 6
            0.0f, 0.0f, // 

        0.0f, 0.5f, 0.0f, // 7
            0.0f, 1.0f, // end tri 8

        // ------------------

        3.0f, -0.5f, -0.5f, // 1
            0.0f, 0.0f,  // 

        3.0f, 0.5f, -0.5f, // 2
            1.0f, 0.0f, // 

        3.0f, -0.5f, 0.0f, // 5
            1.0f, 1.0f, // end tri 9

        // ------------------

        3.0f, -0.5f, 0.0f, // 5
            0.0f, 0.0f,  // 

        3.0f, 0.5f, -0.5f, // 2
            0.0f, 1.0f, // 

        3.0f, 0.5f, 0.0f, // 6
            1.0f, 1.0f, // end tri 10

        // ------------------

        0.0f, -0.5f, -0.5f, // 0
            0.0f, 0.0f,  // red

        0.0f, 0.5f, -0.5f, // 3
            1.0f, 0.0f, //

        0.0f, -0.5f, 0.0f, // 4
            1.0f, 1.0f, // end tri 11

        // ------------------

        0.0f, -0.5f, 0.0f, // 4
            0.0f, 0.0f,  // 

        0.0f, 0.5f, -0.5f, // 3
            0.0f, 1.0f,//

        0.0f, 0.5f, 0.0f, // 7
            1.0f, 1.0f, // end tri 12


    };

    const GLuint floatsPerVertex2 = 3;
    const GLuint floatsPerUV2 = 2;

    mesh.cuboidVertices = sizeof(cuboidVerts) / (sizeof(cuboidVerts[0]) * (floatsPerVertex2 + floatsPerUV2));

    glGenVertexArrays(1, &mesh.cuboidVao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.cuboidVao);

    // Create VBO
    glGenBuffers(1, &mesh.cuboidVbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.cuboidVbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(cuboidVerts), cuboidVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates
    GLint stride2 = sizeof(float) * (floatsPerVertex2 + floatsPerUV2);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex2, GL_FLOAT, GL_FALSE, stride2, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerUV2, GL_FLOAT, GL_FALSE, stride2, (char*)(sizeof(float) * floatsPerVertex2));
    glEnableVertexAttribArray(1);

}

// Implements the UCreateMeshLens function
void UCreateMeshLens(GLMesh& mesh)
{

    GLfloat lensVerts[] = {

        -2.0f, -1.0f, -0.5f, // 0
            0.0f, 0.0f,

        0.0f, -1.0f, -0.5f, // 1
            1.0f, 0.0f,

        0.0f, 1.0f, -0.5f, // 2
            1.0f, 1.0f, // end tri 1

        // ------------------

        -2.0f, -1.0f, -0.5f, // 0
            0.0f, 0.0f,

        0.0f, 1.0f, -0.5f, // 2
            0.0f, 1.0f,

        -2.0f, 1.0f, -0.5f, // 3
            1.0f, 1.0f, // end tri 2

        // ------------------

        -2.0f, -1.0f, 0.0f, // 4
            1.0f, 1.0f,

        0.0f, -1.0f, 0.0f, // 5
            1.0f, 0.0f,

        0.0f, 1.0f, 0.0f, // 6
            0.0f, 0.0f,// end tri 3

        // ------------------

        -2.0f, -1.0f, 0.0f, // 4
            1.0f, 1.0f,

        0.0f, 1.0f, 0.0f, // 6
            0.0f, 0.0f,

        -2.0f, 1.0f, 0.0f, // 7
            0.0f, 1.0f, // end tri 4

        // ------------------

        -2.0f, -1.0f, -0.5f, // 0
            0.0f, 0.0f,

        0.0f, -1.0f, -0.5f, // 1
            1.0f, 0.0f,

        0.0f, -1.0f, 0.0f, // 5
            1.0f, 1.0f,// end tri 5

        // ------------------

        -2.0f, -1.0f, -0.5f, // 0
            0.0f, 0.0f,

        -2.0f, -1.0f, 0.0f, // 4
            0.0f, 1.0f,

        0.0f, -1.0f, 0.0f, // 5
            1.0f, 1.0f, // end tri 6

        // ------------------

        0.0f, 1.0f, -0.5f, // 2
            0.0f, 0.0f,

        -2.0f, 1.0f, -0.5f, // 3
            1.0f, 0.0f,// 

        0.0f, 1.0f, 0.0f, // 6
            1.0f, 1.0f, // end tri 7

        // ------------------

        -2.0f, 1.0f, -0.5f, // 3
            0.0f, 0.0f, // 

        0.0f, 1.0f, 0.0f, // 6
            0.0f, 1.0f,

        -2.0f, 1.0f, 0.0f, // 7
            1.0f, 1.0f, // end tri 8

        // ------------------

        0.0f, -1.0f, -0.5f, // 1
            0.0f, 0.0f,

        0.0f, 1.0f, -0.5f, // 2
            1.0f, 0.0f,

        0.0f, 1.0f, 0.0f, // 6
            1.0f, 1.0f, // end tri 9

        // ------------------

        0.0f, -1.0f, -0.5f, // 1
            0.0f, 0.0f,

        0.0f, 1.0f, 0.0f, // 6
            0.0f, 1.0f,

        0.0f, -1.0f, 0.0f, // 5
            1.0f, 1.0f, // end tri 10

        // ------------------

        -2.0f, -1.0f, -0.5f, // 0
            0.0f, 0.0f,

        -2.0f, 1.0f, -0.5f, // 3
            1.0f, 0.0f, // 

        0.0f, 1.0f, 0.0f, // 6
            1.0f, 1.0f, // end tri 11

        // ------------------

        -2.0f, -1.0f, -0.5f, // 0
            0.0f, 0.0f,

        0.0f, 1.0f, 0.0f, // 6
            0.0f, 1.0f,

        -2.0f, -1.0f, 0.0f, // 4
            1.0f, 1.0f, // end tri 12
    };

    const GLuint floatsPerVertex3 = 3;
    const GLuint floatsPerUV3 = 2;

    mesh.lensVertices = sizeof(lensVerts) / (sizeof(lensVerts[0]) * (floatsPerVertex3 + floatsPerUV3));

    glGenVertexArrays(1, &mesh.lensVao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.lensVao);

    // Create VBO
    glGenBuffers(1, &mesh.lensVbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.lensVbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(lensVerts), lensVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates
    GLint stride3 = sizeof(float) * (floatsPerVertex3 + floatsPerUV3);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex3, GL_FLOAT, GL_FALSE, stride3, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerUV3, GL_FLOAT, GL_FALSE, stride3, (char*)(sizeof(float)* floatsPerVertex3));
    glEnableVertexAttribArray(1);

}




// ADDED FOR MOD 6 MILESTONE
// Implements the UCreateMeshLens function
void UCreateMeshLight(GLMesh& mesh)
{

    GLfloat lightVerts[] = {

        -1.0f, -0.5f, 5.0f, // 0
            0.0f, 0.0f,

        0.0f, -0.5f, 5.0f, // 1
            1.0f, 0.0f,

        0.0f, 0.5f, 5.0f, // 2
            1.0f, 1.0f, // end tri 1

        // ------------------

        -1.0f, -0.5f, 5.0f, // 0
            0.0f, 0.0f,

        0.0f, 0.5f, 5.0f, // 2
            0.0f, 1.0f,

        -1.0f, 0.5f, 5.0f, // 3
            1.0f, 1.0f, // end tri 2

        // ------------------

        -1.0f, -0.5f, 5.5f, // 4
            1.0f, 1.0f,

        0.0f, -0.5f, 5.5f, // 5
            1.0f, 0.0f,

        0.0f, 0.5f, 5.5f, // 6
            0.0f, 0.0f,// end tri 3

        // ------------------

        -1.0f, -0.5f, 5.5f, // 4
            1.0f, 1.0f,

        0.0f, 0.5f, 5.5f, // 6
            0.0f, 0.0f,

        -1.0f, 0.5f, 5.5f, // 7
            0.0f, 1.0f, // end tri 4

        // ------------------

        -1.0f, -0.5f, 5.0f, // 0
            0.0f, 0.0f,

        0.0f, -0.5f, 5.0f, // 1
            1.0f, 0.0f,

        0.0f, -0.5f, 5.5f, // 5
            1.0f, 1.0f,// end tri 5

        // ------------------

        -1.0f, -0.5f, 5.0f, // 0
            0.0f, 0.0f,

        -1.0f, -0.5f, 5.5f, // 4
            0.0f, 1.0f,

        0.0f, -0.5f, 5.5f, // 5
            1.0f, 1.0f, // end tri 6

        // ------------------

        0.0f, 0.5f, 5.0f, // 2
            0.0f, 0.0f,

        -1.0f, 0.5f, 5.0f, // 3
            1.0f, 0.0f,// 

        0.0f, 0.5f, 5.5f, // 6
            1.0f, 1.0f, // end tri 7

        // ------------------

        -1.0f, 0.5f, 5.0f, // 3
            0.0f, 0.0f, // 

        0.0f, 0.5f, 5.5f, // 6
            0.0f, 1.0f,

        -1.0f, 0.5f, 5.5f, // 7
            1.0f, 1.0f, // end tri 8

        // ------------------

        0.0f, -0.5f, 5.0f, // 1
            0.0f, 0.0f,

        0.0f, 0.5f, 5.0f, // 2
            1.0f, 0.0f,

        0.0f, 0.5f, 5.5f, // 6
            1.0f, 1.0f, // end tri 9

        // ------------------

        0.0f, -0.5f, 5.0f, // 1
            0.0f, 0.0f,

        0.0f, 0.5f, 5.5f, // 6
            0.0f, 1.0f,

        0.0f, -0.5f, 5.5f, // 5
            1.0f, 1.0f, // end tri 10

        // ------------------

        -1.0f, -0.5f, 5.0f, // 0
            0.0f, 0.0f,

        -1.0f, 0.5f, 5.0f, // 3
            1.0f, 0.0f, // 

        0.0f, 0.5f, 5.5f, // 6
            1.0f, 1.0f, // end tri 11

        // ------------------

        -1.0f, -0.5f, 5.0f, // 0
            0.0f, 0.0f,

        0.0f, 0.5f, 5.5f, // 6
            0.0f, 1.0f,

        -1.0f, -0.5f, 5.5f, // 4
            1.0f, 1.0f, // end tri 12
    };

    const GLuint floatsPerVertex4 = 3;
    const GLuint floatsPerUV4 = 2;

    mesh.lightVertices = sizeof(lightVerts) / (sizeof(lightVerts[0]) * (floatsPerVertex4 + floatsPerUV4));

    glGenVertexArrays(1, &mesh.lightVao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.lightVao);

    // Create VBO
    glGenBuffers(1, &mesh.lightVbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.lightVbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(lightVerts), lightVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates
    GLint stride4 = sizeof(float) * (floatsPerVertex4 + floatsPerUV4);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex4, GL_FLOAT, GL_FALSE, stride4, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerUV4, GL_FLOAT, GL_FALSE, stride4, (char*)(sizeof(float) * floatsPerVertex4));
    glEnableVertexAttribArray(1);

}
// END ADDED FOR MOD 6 MILESTONE

// Implements the UCreateMeshDunder function
void UCreateMeshDunder(GLMesh& mesh)
{
    // Vertex data
    GLfloat dunderVerts[] = {
         7.0f, 6.0f, -0.4f, 1.0f, 0.0f, // 0 
        9.0f, 6.0f, -0.4f, 0.0f, 0.0f, // 1  
        9.0f, 9.0f, -0.4f, 0.0f, 1.0f,// 2 
         // End tri 1

        // ------------------
        7.0f, 6.0f, -0.4f, 1.0f, 0.0f, // 0
        9.0f, 9.0f, -0.4f, 0.0f, 1.0f,// 2
        7.0f, 9.0f, -0.4f, 1.0f, 1.0f, // 3
         // End tri 2
    };

    const GLuint floatsPerVertex5 = 3;
    const GLuint floatsPerUV5 = 2;

    mesh.dunderVertices = sizeof(dunderVerts) / (sizeof(dunderVerts[0]) * (floatsPerVertex5 + floatsPerUV5));

    glGenVertexArrays(1, &mesh.dunderVao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.dunderVao);

    // Create VBO
    glGenBuffers(1, &mesh.dunderVbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.dunderVbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(dunderVerts), dunderVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates
    GLint stride5 = sizeof(float) * (floatsPerVertex5 + floatsPerUV5);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex5, GL_FLOAT, GL_FALSE, stride5, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerUV5, GL_FLOAT, GL_FALSE, stride5, (char*)(sizeof(float) * floatsPerVertex5));
    glEnableVertexAttribArray(1);

}


// Implements the UCreateMeshMap function
void UCreateMeshMap(GLMesh& mesh)
{
    // Vertex data
    GLfloat mapVerts[] = {

        5.0f, -0.5f, -0.5f, // 0 
        1.0f, 0.0f,  // red 

        7.0f, -0.5f, -0.5f, // 1
        0.0f, 0.0f, // 

        7.0f, 1.5f, -0.5f, // 2
        0.0f, 1.0f, // end tri 1

        // ------------------

        5.0f, -0.5f, -0.5f, // 0
            1.0f, 0.0f,  // 

        7.0f, 1.5f, -0.5f, // 2
            0.0f, 1.0f, //  

        5.0f, 1.5f, -0.5f, // 3
            1.0f, 1.0f, // end tri 2

        // ------------------

        5.0f, -0.5f, -0.5f, // 0
            0.0f, 0.0f, // red

        7.0f, -0.5f, -0.5f, // 1
            1.0f, 0.0f, // 

        7.0f, -0.5f, 1.5f, // 5
            1.0f, 1.0f,// end tri 3

        // ------------------

        5.0f, -0.5f, -0.5f, // 0
            0.0f, 0.0f,  // red

        5.0f, -0.5f, 1.5f, // 4
            0.0f, 1.0f, // red

        7.0f, -0.5f, 1.5f, // 5
            1.0f, 1.0f,// end tri 4

        // ------------------

        7.0f, 1.5f, -0.5f, // 2
            1.0f, 0.0f,  // 

        5.0f, 1.5f, -0.5f, // 3
            1.0f, 1.0f, // 

        7.0f, 1.5f, 1.5f, // 6
            0.0f, 0.0f, // end tri 5

        // ------------------

        7.0f, 1.5f, 1.5f, // 6
            0.0f, 0.0f,  // 

        5.0f, 1.5f, -0.5f, // 3
            1.0f, 1.0f, //

        5.0f, 1.5f, 1.5f, // 7
            0.0f, 1.0f, // end tri 6

        // ------------------

        5.0f, -0.5f, 1.5f, // 4
            1.0f, 1.0f,  // red

        7.0f, -0.5f, 1.5f, // 5
            1.0f, 0.0f, // 

        7.0f, 1.5f, 1.5f, // 6
            0.0f, 0.0f, // end tri 7

        // ------------------

        5.0f, -0.5f, 1.5f, // 4
            1.0f, 1.0f,  // red

        7.0f, 1.5f, 1.5f, // 6
            0.0f, 0.0f, // 

        5.0f, 1.5f, 1.5f, // 7
            0.0f, 1.0f, // end tri 8

        // ------------------

        7.0f, -0.5f, -0.5f, // 1 
            1.0f, 0.0f,  // 

        7.0f, 1.5f, -0.5f, // 2
            0.0f, 0.0f, // 

        7.0f, -0.5f, 1.5f, // 5
            1.0f, 1.0f, // end tri 9

        // ------------------

        7.0f, -0.5f, 1.5f, // 5 
            1.0f, 1.0f,  // 

        7.0f, 1.5f, -0.5f, // 2
            0.0f, 0.0f, // 

        7.0f, 1.5f, 1.5f, // 6 
            0.0f, 1.0f, // end tri 10

        // ------------------

        5.0f, -0.5f, -0.5f, // 0
            1.0f, 0.0f,  // red

        5.0f, 1.5f, -0.5f, // 3
            0.0f, 0.0f, //

        5.0f, -0.5f, 1.5f, // 4
            1.0f, 1.0f, // end tri 11

        // ------------------

        5.0f, -0.5f, 1.5f, // 4
            1.0f, 1.0f,  // 

        5.0f, 1.5f, -0.5f, // 3
            0.0f, 0.0f,//

        5.0f, 1.5f, 1.5f, // 7
            0.0f, 1.0f, // end tri 12
    };

    const GLuint floatsPerVertex6 = 3;
    const GLuint floatsPerUV6 = 2;

    mesh.mapVertices = sizeof(mapVerts) / (sizeof(mapVerts[0]) * (floatsPerVertex6 + floatsPerUV6));

    glGenVertexArrays(1, &mesh.mapVao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.mapVao);

    // Create VBO
    glGenBuffers(1, &mesh.mapVbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.mapVbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(mapVerts), mapVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates
    GLint stride6 = sizeof(float) * (floatsPerVertex6 + floatsPerUV6);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex6, GL_FLOAT, GL_FALSE, stride6, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerUV6, GL_FLOAT, GL_FALSE, stride6, (char*)(sizeof(float) * floatsPerVertex6));
    glEnableVertexAttribArray(1);

}

// Implements the UCreateMeshRubik function
void UCreateMeshRubik(GLMesh& mesh)
{
    // Vertex data
    GLfloat rubikVerts[] = {

        0.0f, 6.0f, -0.5f, // 0 
        1.0f, 0.0f,  // red 

        2.0f, 6.0f, -0.5f, // 1
        0.0f, 0.0f, // 

        2.0f, 8.0f, -0.5f, // 2
        0.0f, 1.0f, // end tri 1

        // ------------------

        0.0f, 6.0f, -0.5f, // 0
            1.0f, 0.0f,  // 

        2.0f, 8.0f, -0.5f, // 2
            0.0f, 1.0f, //  

        0.0f, 8.0f, -0.5f, // 3
            1.0f, 1.0f, // end tri 2 

        // ------------------

        0.0f, 6.0f, -0.5f, // 0 
            0.0f, 0.0f, // red

        2.0f, 6.0f, -0.5f, // 1
            1.0f, 0.0f, // 

        2.0f, 6.0f, 1.5f, // 5
            1.0f, 1.0f,// end tri 3

        // ------------------

        0.0f, 6.0f, -0.5f, // 0
            0.0f, 0.0f,  // red

        0.0f, 6.0f, 1.5f, // 4
            0.0f, 1.0f, // red

        2.0f, 6.0f, 1.5f, // 5
            1.0f, 1.0f,// end tri 4 

        // ------------------

        2.0f, 8.0f, -0.5f, // 2
            0.0f, 1.0f,  // 

        0.0f, 8.0f, -0.5f, // 3
            0.0f, 0.0f, // 

        2.0f, 8.0f, 1.5f, // 6
            1.0f, 1.0f, // end tri 5 

        // ------------------

        2.0f, 8.0f, 1.5f, // 6
            0.0f, 0.0f,  // 

        0.0f, 8.0f, -0.5f, // 3 
            1.0f, 1.0f, //

        0.0f, 8.0f, 1.5f, // 7
            1.0f, 0.0f, // end tri 6 

        // ------------------

        0.0f, 6.0f, 1.5f, // 4
            1.0f, 1.0f,  // red

        2.0f, 6.0f, 1.5f, // 5
            1.0f, 0.0f, // 

        2.0f, 8.0f, 1.5f, // 6
            0.0f, 0.0f, // end tri 7

        // ------------------

        0.0f, 6.0f, 1.5f, // 4
            1.0f, 1.0f,  // red

        2.0f, 8.0f, 1.5f, // 6
            0.0f, 0.0f, // 

        0.0f, 8.0f, 1.5f, // 7
            0.0f, 1.0f, // end tri 8 

        // ------------------

        2.0f, 6.0f, -0.5f, // 1 
            1.0f, 0.0f,  // 

        2.0f, 8.0f, -0.5f, // 2
            1.0f, 1.0f, // 

        2.0f, 6.0f, 1.5f, // 5
            0.0f, 0.0f, // end tri 9

        // ------------------

        2.0f, 6.0f, 1.5f, // 5 
            1.0f, 1.0f,  // 

        2.0f, 8.0f, -0.5f, // 2 
            0.0f, 0.0f, // 

        2.0f, 8.0f, 1.5f, // 6 
            1.0f, 0.0f, // end tri 10 

        // ------------------

        0.0f, 6.0f, -0.5f, // 0 
            1.0f, 0.0f,  // red

        0.0f, 8.0f, -0.5f, // 3
            0.0f, 0.0f, //

        0.0f, 6.0f, 1.5f, // 4
            1.0f, 1.0f, // end tri 11

        // ------------------

        0.0f, 6.0f, 1.5f, // 4 
            1.0f, 1.0f,  // 

        0.0f, 8.0f, -0.5f, // 3
            0.0f, 0.0f,//

        0.0f, 8.0f, 1.5f, // 7
            0.0f, 1.0f, // end tri 12 
    };

    const GLuint floatsPerVertex7 = 3;
    const GLuint floatsPerUV7 = 2;

    mesh.rubikVertices = sizeof(rubikVerts) / (sizeof(rubikVerts[0]) * (floatsPerVertex7 + floatsPerUV7));

    glGenVertexArrays(1, &mesh.rubikVao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.rubikVao);

    // Create VBO
    glGenBuffers(1, &mesh.rubikVbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.rubikVbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(rubikVerts), rubikVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates
    GLint stride6 = sizeof(float) * (floatsPerVertex7 + floatsPerUV7);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex7, GL_FLOAT, GL_FALSE, stride6, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerUV7, GL_FLOAT, GL_FALSE, stride6, (char*)(sizeof(float) * floatsPerVertex7));
    glEnableVertexAttribArray(1);

}


void UDestroyMesh(GLMesh &mesh)
{
    glDeleteVertexArrays(1, &mesh.planeVao);
    glDeleteBuffers(1, &mesh.planeVbo);

    glDeleteVertexArrays(1, &mesh.cuboidVao);
    glDeleteBuffers(1, &mesh.cuboidVbo); 

    glDeleteVertexArrays(1, &mesh.lensVao);
    glDeleteBuffers(1, &mesh.lensVbo);

    glDeleteVertexArrays(1, &mesh.lightVao);
    glDeleteBuffers(1, &mesh.lightVbo);

    glDeleteVertexArrays(1, &mesh.dunderVao);
    glDeleteBuffers(1, &mesh.dunderVbo);

    glDeleteVertexArrays(1, &mesh.mapVao);
    glDeleteBuffers(1, &mesh.mapVbo);

    glDeleteVertexArrays(1, &mesh.rubikVao);
    glDeleteBuffers(1, &mesh.rubikVbo);

}




/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}


void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}




// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint &programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}
